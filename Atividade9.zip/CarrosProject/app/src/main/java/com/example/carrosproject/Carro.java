package com.example.carrosproject;

public class Carro {
    private String nome;
    private String placa;
    private int ano;
    public Carro() {

    }
    public String getNome() {
        return nome;
    }

    public String getPlaca() {
        return placa;
    }

    public int getAno() {
        return ano;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
}


