package com.example.carrosproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MeuDatabase extends SQLiteOpenHelper {

    public MeuDatabase(@Nullable Context context) {
        super(context, "bancoCarros", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS carros(id INTEGER PRIMARY KEY AUTOINCREMENT,"+"nome TEXT, placa TEXT, ano INTEGER);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public int cadastrar(Carro c){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("nome",c.getNome());
        contentValues.put("placa",c.getPlaca());
        contentValues.put("ano",c.getAno());
        try{
            sqLiteDatabase.insert("carros",null,contentValues);
            return 1;
        }catch (Exception e){
            return 0;
        }


    }
    public Cursor consultar(){
        SQLiteDatabase sqLiteDatabase1 = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase1.rawQuery("select * from carros", null);
        cursor.moveToFirst();
        return cursor;
    }
    public boolean atualizar(String id, String nome, String placa, String ano) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("nome", nome);
        contentValues.put("placa", placa);
        contentValues.put("ano", ano);

        int rowsAffected = db.update("carros", contentValues, "id = ?", new String[]{id});
        return rowsAffected > 0;
    }

    public boolean excluir(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete("carros", "id = ?", new String[]{id});
        return rowsAffected > 0;
    }
}
