package com.example.carrosproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText et_nome, et_placa, et_ano;
    Button bt_cadastrar, bt_telaConsulta;
    MeuDatabase banco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        banco = new MeuDatabase(MainActivity.this);
        setContentView(R.layout.activity_main);

        et_nome = findViewById(R.id.editTextNome);
        et_placa = findViewById(R.id.editTextPlaca);
        et_ano = findViewById(R.id.editTextAno);
        bt_cadastrar = findViewById(R.id.buttonCadastrar);
        bt_telaConsulta = findViewById(R.id.buttonConsultar);
        bt_cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                inserirRegistro();
            }
        });
        bt_telaConsulta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, TELA2.class);
                startActivity(i);
            }
        });
    }
    public void inserirRegistro(){
        Carro carro = new Carro();

        try {
            carro.setNome(et_nome.getText().toString());
            carro.setPlaca((et_placa.getText().toString()));
            carro.setAno(Integer.parseInt(et_ano.getText().toString()));
            if(banco.cadastrar(carro) == 1){
            Log.d("BANCO","Cadastrado com sucesso");
            Toast.makeText(MainActivity.this,"Cadastrado com sucesso", Toast.LENGTH_SHORT).show();
            et_nome.setText(null);
            et_placa.setText(null);
            et_ano.setText(null);
            }else{
                Log.d("BANCO", "Erro ao Cadastrar");
            }
        }catch (Exception e){
            Log.e("BANCO", "Erro ao cadastrar");
        }
    }
    public void abriTelaConsulta (View v){
        Intent abriTela = new Intent(this, TELA2.class);
        startActivity(abriTela);


    }
}