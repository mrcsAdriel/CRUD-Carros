package com.example.carrosproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TELA2 extends AppCompatActivity {
    EditText et_nome, et_placa, et_ano;
    Button bt_anterior, bt_proximo, bt_voltar, bt_atualizar, bt_excluir;
    MeuDatabase banco;
    Cursor cursor;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        et_nome = findViewById(R.id.editTextText2);
        et_placa = findViewById(R.id.editTextText3);
        et_ano = findViewById(R.id.editTextText4);
        bt_anterior = findViewById(R.id.buttonAnterior);
        bt_proximo = findViewById(R.id.buttonProximo);
        bt_atualizar = findViewById(R.id.buttonAtualizar);
        bt_excluir = findViewById(R.id.buttonExcluir);
        bt_anterior = findViewById(R.id.buttonAnterior);
        bt_voltar = findViewById(R.id.buttonVoltar);
        banco = new MeuDatabase(TELA2.this);
        buscarDados();
        bt_proximo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                proximo();

            }
        });
        bt_anterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                anterior();
            }
        });
        bt_atualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                atualizar();
            }
        });
        bt_excluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                excluir();
            }
        });
        bt_voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(TELA2.this, MainActivity.class);
                startActivity(i);
            }
        });


    }
    public void proximo(){
        try{
            cursor.moveToNext();
            mostrarDados(cursor);
        }
        catch(Exception e){
            if (cursor.isAfterLast()){
                cursor.moveToPrevious();
                Toast.makeText(TELA2.this, "Não existe mais registro",Toast.LENGTH_SHORT).show();
            }else{
                Log.e("ERRO", "ERRO AO NAVEGAR PELOS REGISTROS");
            }
        }
    }
    public void anterior(){
        try{
            cursor.moveToPrevious();
            mostrarDados(cursor);
        }catch (Exception e){
            if (cursor.isBeforeFirst()){
                cursor.moveToNext();
                Toast.makeText(TELA2.this, "Não existe mais registros", Toast.LENGTH_SHORT).show();
            }else{
                Log.e("ERRO", "Erro ao navegar pelos registros");
            }
        }
    }
    public void buscarDados(){

        cursor = banco.consultar();

        if(cursor.getCount()!=0){
            mostrarDados(cursor);
        }else{
            Log.d("Banco","Nenhum registro encontrado");
        }
    }

    @SuppressLint("Range")
    public void mostrarDados (Cursor c){
        et_nome.setText(cursor.getString(cursor.getColumnIndex("nome")));
        et_placa.setText(cursor.getString(cursor.getColumnIndex("placa")));
        et_ano.setText(cursor.getString(cursor.getColumnIndex("ano")));
    }
    public void fechar (View v){
        this.finish();
    }
    @SuppressLint("Range")
    public void atualizar(){
        String nome = et_nome.getText().toString();
        String placa = et_placa.getText().toString();
        String ano = et_ano.getText().toString();
        String id = cursor.getString(cursor.getColumnIndex("id"));

        if (banco.atualizar(id, nome, placa, ano)){
            Toast.makeText(TELA2.this, "Registro atualizado com sucesso!", Toast.LENGTH_SHORT).show();
            buscarDados();
        } else{
            Toast.makeText(TELA2.this, "Erro ao atualizar registro", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("Range")
    public void excluir(){
        String id = cursor.getString(cursor.getColumnIndex("id"));
        if (banco.excluir(id)){
            Toast.makeText(TELA2.this, "Registro excluído com sucesso!", Toast.LENGTH_SHORT).show();
            buscarDados();
        } else{
            Toast.makeText(TELA2.this, "Erro ao excluir registro", Toast.LENGTH_SHORT).show();
        }
    }
}